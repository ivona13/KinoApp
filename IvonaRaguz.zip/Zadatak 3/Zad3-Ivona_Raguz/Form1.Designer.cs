﻿namespace Zad3_Ivona_Raguz
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.dodajLijevo = new System.Windows.Forms.Button();
            this.dodajDesno = new System.Windows.Forms.Button();
            this.ukloniLijevo = new System.Windows.Forms.Button();
            this.ukloniDesno = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.ukloniLijevo);
            this.splitContainer1.Panel1.Controls.Add(this.dodajLijevo);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.statusStrip1);
            this.splitContainer1.Panel2.Controls.Add(this.ukloniDesno);
            this.splitContainer1.Panel2.Controls.Add(this.dodajDesno);
            this.splitContainer1.Size = new System.Drawing.Size(800, 450);
            this.splitContainer1.SplitterDistance = 371;
            this.splitContainer1.TabIndex = 0;
            // 
            // dodajLijevo
            // 
            this.dodajLijevo.Location = new System.Drawing.Point(181, 12);
            this.dodajLijevo.Name = "dodajLijevo";
            this.dodajLijevo.Size = new System.Drawing.Size(82, 38);
            this.dodajLijevo.TabIndex = 0;
            this.dodajLijevo.Text = "Dodaj";
            this.dodajLijevo.UseVisualStyleBackColor = true;
            this.dodajLijevo.Click += new System.EventHandler(this.dodajLijevo_Click);
            // 
            // dodajDesno
            // 
            this.dodajDesno.Location = new System.Drawing.Point(235, 12);
            this.dodajDesno.Name = "dodajDesno";
            this.dodajDesno.Size = new System.Drawing.Size(83, 38);
            this.dodajDesno.TabIndex = 1;
            this.dodajDesno.Text = "Dodaj";
            this.dodajDesno.UseVisualStyleBackColor = true;
            this.dodajDesno.Click += new System.EventHandler(this.dodajDesno_Click);
            // 
            // ukloniLijevo
            // 
            this.ukloniLijevo.Location = new System.Drawing.Point(269, 12);
            this.ukloniLijevo.Name = "ukloniLijevo";
            this.ukloniLijevo.Size = new System.Drawing.Size(86, 38);
            this.ukloniLijevo.TabIndex = 1;
            this.ukloniLijevo.Text = "Ukloni";
            this.ukloniLijevo.UseVisualStyleBackColor = true;
            this.ukloniLijevo.Click += new System.EventHandler(this.ukloniLijevo_Click);
            // 
            // ukloniDesno
            // 
            this.ukloniDesno.Location = new System.Drawing.Point(324, 12);
            this.ukloniDesno.Name = "ukloniDesno";
            this.ukloniDesno.Size = new System.Drawing.Size(89, 38);
            this.ukloniDesno.TabIndex = 2;
            this.ukloniDesno.Text = "Ukloni";
            this.ukloniDesno.UseVisualStyleBackColor = true;
            this.ukloniDesno.Click += new System.EventHandler(this.ukloniDesno_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2});
            this.statusStrip1.Location = new System.Drawing.Point(0, 420);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(425, 30);
            this.statusStrip1.TabIndex = 3;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(179, 25);
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(179, 25);
            this.toolStripStatusLabel2.Text = "toolStripStatusLabel2";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.splitContainer1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button dodajLijevo;
        private System.Windows.Forms.Button dodajDesno;
        private System.Windows.Forms.Button ukloniLijevo;
        private System.Windows.Forms.Button ukloniDesno;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
    }
}

