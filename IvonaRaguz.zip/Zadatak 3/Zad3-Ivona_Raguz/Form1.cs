﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zad3_Ivona_Raguz
{
    public partial class Form1 : Form
    {
        int brojButtonaLijevo = 0, brojButtonaDesno = 0;
        int dodano = 0, kliknuto = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // splitContainer1.SplitterDistance = Width / 2;
            toolStripStatusLabel1.Text = "Dodano: 0";
            toolStripStatusLabel2.Text = "Kliknuto: 0"; 

        }

        private void dodajLijevo_Click(object sender, EventArgs e)
        {
            brojButtonaLijevo++;
            dodano++;
            Button button = new Button();
            button.Text = new StringBuilder().Append("Gumb").Append(brojButtonaLijevo.ToString()).ToString();
            button.Size = new Size(100, 35);
            button.Location = new Point(20, 10 + brojButtonaLijevo * button.Height);
            splitContainer1.Panel1.Controls.Add(button);
            toolStripStatusLabel1.Text = "Dodano: " + dodano.ToString();
            if (button.Location.Y > Height)
            {
                splitContainer1.Panel1.AutoScroll = true;

            }
            button.Click += klikListener;
        }

        private void ukloniLijevo_Click(object sender, EventArgs e)
        {
            foreach(Button b in splitContainer1.Panel1.Controls.OfType<Button>().ToArray())
            {
                if(b.Text.StartsWith("Gumb"))
                {
                    splitContainer1.Panel1.Controls.Remove(b);
                }
            }

            brojButtonaLijevo = 0;
        }

        private void ukloniDesno_Click(object sender, EventArgs e)
        {
            foreach (Button b in splitContainer1.Panel2.Controls.OfType<Button>().ToArray())
            {
                if (b.Text.StartsWith("Gumb"))
                {
                    splitContainer1.Panel2.Controls.Remove(b);
                }
            }

            brojButtonaDesno = 0;
        }

        private void dodajDesno_Click(object sender, EventArgs e)
        {
            brojButtonaDesno++;
            dodano++;
            Button button = new Button();
            button.Text = new StringBuilder().Append("Gumb").Append(brojButtonaDesno.ToString()).ToString();
            button.Size = new Size(100, 35);
            button.Location = new Point(20, 10 + brojButtonaDesno * button.Height);
            splitContainer1.Panel2.Controls.Add(button);
            toolStripStatusLabel1.Text = "Dodano: " + dodano.ToString();
            if (button.Location.Y > Height)
            {
                splitContainer1.Panel2.AutoScroll = true;

            }

            button.Click += klikListener;

        }

        private void klikListener(object sender, EventArgs e)
        {
            Button b =  (Button)sender;

            StringBuilder sb = new StringBuilder();
            sb.Append("Na ");
            if(splitContainer1.Panel1.Controls.OfType<Button>().Contains(b))
            {
                sb.Append("lijevoj strani, ").Append(b.Text);
                MessageBox.Show(sb.ToString());
                kliknuto++;
                toolStripStatusLabel2.Text = "Kliknuto:" + kliknuto.ToString();
            }
            else 
            {
                sb.Append("desnoj strani, ").Append(b.Text);
                MessageBox.Show(sb.ToString());
                kliknuto++;
                toolStripStatusLabel2.Text = "Kliknuto: " + kliknuto.ToString();

            }
        }
    }
}
