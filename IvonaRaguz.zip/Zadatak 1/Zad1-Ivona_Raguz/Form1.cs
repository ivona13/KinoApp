﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zad1_Ivona_Raguz
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            smanji.Height = 50;
            smanji.Width = Width;
            smanji.Location = new Point(0, 0);
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            smanji.Height = smanji.Height / 2;
        }

        private void smanji_Click(object sender, EventArgs e)
        {

            Thread.Sleep(2000);
            Height = (int)(Height - 0.2* Height);
        }
    }
}
