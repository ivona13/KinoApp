﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zad2_Ivona_Raguz
{
    public partial class Form1 : Form
    {
        Label label1, label2, label3, label4;
        public Form1()
        {
            InitializeComponent();
        }

        public Form1(Form f, double sirina, double visina)
        {
            InitializeComponent();
            Height = (int)visina;
            Location = new Point(0, 0);
            Width = (int)sirina;
        }

        private void prikažiToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2(this);
            form.ShowDialog();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            label1 = new Label();
            label1.Text = "I";
            label1.Name = "l1";


            label2 = new Label();
            label2.Text = "II";
            label2.Name = "l2";

            label3 = new Label();
            label3.Text = "III";
            label3.Name = "l3";


            label4 = new Label();
            label4.Text = "IV";
            label4.Name = "l4";


            int x = menuStrip1.Size.Width, y = menuStrip1.Size.Height;

            label1.Size = new Size(Width / 2, (ClientSize.Height)/2);
            label2.Size = new Size(Width / 2, (ClientSize.Height) / 2);
            label3.Size = new Size(Width / 2, (ClientSize.Height) / 2);
            label4.Size = new Size(Width / 2, (ClientSize.Height) / 2);

            label1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Right;
            label2.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Right;
            label3.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Right;
            label4.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Right;

            label1.Location = new Point(0, y);
            label2.Location = new Point(ClientSize.Width / 2 + 5, y);
            label3.Location = new Point(0, ClientSize.Height / 2 +y);
            label4.Location = new Point(ClientSize.Width / 2 + 5, ClientSize.Height / 2 +y);

           

            Controls.Add(label1); Controls.Add(label2); Controls.Add(label3); Controls.Add(label4);

            label1.Click += klik;
            label2.Click += klik;
            label3.Click += klik;
            label4.Click += klik;
        }

        private void klik(object sender, EventArgs e)
        {
            Label l = (Label)sender;
            ColorDialog colorDialog1 = new ColorDialog();
            DialogResult result = colorDialog1.ShowDialog();
            // See if user pressed ok.
            if (result == DialogResult.OK)
            {
                // Set form background to the selected color.
                l.BackColor = colorDialog1.Color;
            }
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
           
        }
    }
}
