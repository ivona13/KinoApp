﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zad2_Ivona_Raguz
{
    public partial class Form2 : Form
    {
        Form1 f;
        public Form2(Form1 form1)
        {
            InitializeComponent();
            f = form1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && textBox2.Text != "")
            {
                double sirina = Double.Parse(textBox1.Text);
                double visina = Double.Parse(textBox2.Text);
               

                Hide();
                f = new Form1(f, sirina, visina);
                f.Show();
                Close();

            }
        }
    }
}
